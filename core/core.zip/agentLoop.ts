import { SkillExecutor } from "./skillExecutor";
import { routeTask } from "../llm/skillRouter";

export class AgentLoop {
  private executor = new SkillExecutor();
  private maxSteps = 5;

  async run(task: string) {
    let context: any = { task };
    let step = 0;

    while (step < this.maxSteps) {
      console.log(`\n--- Step ${step + 1} ---`);

      const decision = await routeTask(context);

      if (decision.type === "finish") {
        console.log("Agent finished.");
        return decision.result;
      }

      const result = await this.executor.execute(
        decision.skill,
        decision.args
      );

      context.lastResult = result;
      step++;
    }

    throw new Error("Max steps reached without finishing.");
  }
}