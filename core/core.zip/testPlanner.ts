import { SkillExecutor } from "./skillExecutor";

async function run() {
  const executor = new SkillExecutor();

  const result = await executor.execute("web.search", {
    query: "AI agents 2026"
  });

  console.log("\nPlanner Result:\n", result);
}

run();