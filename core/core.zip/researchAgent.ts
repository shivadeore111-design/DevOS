import { AgentLoop } from "./agentLoop";
import { appendMemory } from "../memory/memoryEngine";
import { reflectOnResearch } from "./reflectionEngine";
import { readPage } from "../skills/browser/pageReader";

export class ResearchAgent {
  private agent = new AgentLoop();

  async run(topic: string) {
    console.log(`\nResearching: ${topic}\n`);

    try {
      const searchResults = await this.agent.run(`search ${topic}`);

      console.log("Search Results:", searchResults);

      let pageContent = "";

      if (
        Array.isArray(searchResults) &&
        searchResults.length > 0 &&
        searchResults[0].url
      ) {
        console.log("Opening first result...");
        pageContent = await readPage(searchResults[0].url);
      }

      appendMemory("topicsResearched", topic);

      const reflection = await reflectOnResearch(
        topic,
        {
          searchResults,
          pageContent
        }
      );

      console.log("\nUsefulness Score:", reflection.usefulnessScore);
      console.log("Confidence Score:", reflection.confidenceScore);
      console.log("Next Direction:", reflection.strategicDirection);

      console.log("\nDeep research stored successfully.\n");

    } catch (err: any) {
      appendMemory("failures", {
        topic,
        error: err.message
      });

      console.log("Research failed and logged.\n");
    }
  }
}