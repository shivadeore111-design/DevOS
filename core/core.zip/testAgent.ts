import { AgentLoop } from "./agentLoop";

async function run() {
  const agent = new AgentLoop();

  const result = await agent.run("search AI agents 2026");

  console.log("\nFinal Result:\n", result);
}

run();