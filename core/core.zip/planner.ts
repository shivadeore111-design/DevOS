import { askLLM } from "../providers/router";

export interface Action {
  type: "file_create" | "command";
  path?: string;
  content?: string;
  command?: string;
  risk?: "low" | "medium" | "high";
}

export interface Plan {
  summary: string;
  complexity: "low" | "medium" | "high";
  actions: Action[];
}

// ─────────────────────────────────────────────
// Extract first valid JSON block from LLM output
// ─────────────────────────────────────────────

function extractJSON(text: string): string {
  const firstBrace = text.indexOf("{");
  const lastBrace = text.lastIndexOf("}");

  if (firstBrace === -1 || lastBrace === -1) {
    throw new Error("No JSON object found in LLM response.");
  }

  return text.slice(firstBrace, lastBrace + 1);
}

// ─────────────────────────────────────────────
// Generate Plan
// ─────────────────────────────────────────────

export async function generatePlan(goal: string): Promise<Plan> {
  const prompt = `
You are DevOS Planner.

STRICT RULES:
- Output ONLY raw JSON.
- No explanations.
- No markdown.
- No text before or after JSON.

Schema:
{
  "summary": string,
  "complexity": "low" | "medium" | "high",
  "actions": [
    {
      "type": "file_create" | "command",
      "path": string (if file_create),
      "content": string (if file_create),
      "command": string (if command),
      "risk": "low" | "medium" | "high"
    }
  ]
}

Goal: ${goal}
`;

  const raw = await askLLM(prompt);

  try {
    const cleaned = extractJSON(raw);
    const parsed = JSON.parse(cleaned);

    if (!parsed.actions || !Array.isArray(parsed.actions)) {
      throw new Error("Invalid plan format");
    }

    return parsed as Plan;

  } catch (err) {
    console.error("❌ Planner returned invalid JSON.");
    console.error("Raw LLM output:");
    console.error(raw);
    throw err;
  }
}