import { ingestDocument } from "./documentIngestor";

async function run() {
  const filePath = process.argv[2];

  if (!filePath) {
    console.log("Provide file path.");
    return;
  }

  await ingestDocument(filePath);
}

run();