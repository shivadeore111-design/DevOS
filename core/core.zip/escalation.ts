export function generateEscalationReport(
  goal: string,
  failedAction: any,
  error: any
) {
  const report = {
    goal,
    failed_action: failedAction,
    error_message: error?.message || "Unknown error",
    timestamp: new Date().toISOString()
  };

  console.log("\n🚨 CLOUD ESCALATION PACKAGE:");
  console.log(JSON.stringify(report, null, 2));
}